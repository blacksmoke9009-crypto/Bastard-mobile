# BASTARD Android — Chat remoto (primer corte)

## Qué se agregó
- La app Android ahora envía el historial de la conversación a `POST /chat`.
- Ajustes permite guardar URL HTTPS del backend y token de acceso personal.
- Se agregó un backend FastAPI compatible con APIs de chat tipo OpenAI.
- La clave del proveedor queda como variable de entorno del backend, nunca en el APK.

## Backend
En `backend/`:
1. Copiá `.env.example` a `.env` y completá las variables.
2. Instalá dependencias: `pip install -r requirements.txt`.
3. Exportá las variables de entorno del `.env` (o configurá las mismas en el hosting).
4. Ejecutá: `uvicorn main:app --host 0.0.0.0 --port 8000`.
5. Publicá detrás de HTTPS. No expongas el servicio sin HTTPS en internet.

Variables:
- `BASTARD_ACCESS_TOKEN`: token privado para la app (opcional, recomendado).
- `PROVIDER_API_KEY`: clave de tu proveedor de IA.
- `PROVIDER_BASE_URL`: base URL compatible con `/chat/completions`.
- `PROVIDER_MODEL`: nombre del modelo disponible en ese proveedor.

## Android
1. Compilá el proyecto como antes con GitHub Actions.
2. Instalá el APK actualizado.
3. Abrí Ajustes y guardá la URL HTTPS del backend y el token personal.
4. Volvé a Chat y probá.

## Importante
Este paquete es código fuente. El backend todavía debe desplegarse en un hosting y configurarse con una clave de proveedor válida. La compilación Android no fue ejecutada/verificada en este entorno.
