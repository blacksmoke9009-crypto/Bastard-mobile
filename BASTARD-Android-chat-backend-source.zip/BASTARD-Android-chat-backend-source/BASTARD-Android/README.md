# BASTARD for Android — Starter 0.1

Android-first companion for the BASTARD personal AI workspace.

## Stack
- Kotlin + Jetpack Compose + Material 3
- MVVM-ready package structure
- Retrofit/OkHttp can be added for remote provider APIs
- Room can be added for persistent chat history
- Rust core is planned as a native library through JNI/UniFFI; it is not wired into this UI starter yet.

## Open
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Let Gradle sync.
4. Run the `app` configuration on an Android device or emulator.

## Current functionality
- Dark mobile UI and navigation for Chat, Coding, Images, Videos and Settings.
- Chat screen with local demo response (no API key required).
- Provider status placeholders.
- No image/video generation backend is connected yet.

## Architecture notes
The phone is a lightweight client. Model inference should run remotely:
`Android UI -> app ViewModels -> secure backend/API gateway -> model providers / hosted open-weight GPU models`

Do not embed provider API keys in the APK. For a personal deployment, put credentials on a small backend you control and have the app authenticate to it.

## Next milestones
1. Add backend URL + authentication settings.
2. Connect streaming chat endpoint.
3. Add Room conversation history.
4. Add project browser and approval-gated coding agent.
5. Add image generation jobs and result gallery.
6. Add video generation jobs, progress and playback.
7. Integrate Rust core for shared domain logic and secure operations where it materially helps.
