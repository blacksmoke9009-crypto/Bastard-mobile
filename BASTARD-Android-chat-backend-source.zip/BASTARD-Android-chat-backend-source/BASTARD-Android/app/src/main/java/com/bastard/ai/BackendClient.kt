
package com.bastard.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class ChatTurn(val role: String, val content: String)

data class GeneratedImage(
    val base64: String,
    val mimeType: String
)

object BackendClient {

    private fun createConnection(
        backendUrl: String,
        endpoint: String,
        accessToken: String,
        timeout: Int
    ): HttpURLConnection {
        val root = backendUrl.trim().trimEnd('/')

        require(
            root.startsWith("https://") ||
            root.startsWith("http://10.0.2.2")
        ) {
            "Usá una dirección HTTPS para el servidor."
        }

        return (URL("$root/$endpoint").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = timeout
            doOutput = true
            setRequestProperty(
                "Content-Type",
                "application/json; charset=utf-8"
            )

            if (accessToken.isNotBlank()) {
                setRequestProperty(
                    "Authorization",
                    "Bearer $accessToken"
                )
            }
        }
    }

    private fun readResponse(
        connection: HttpURLConnection
    ): String {
        val code = connection.responseCode

        val stream = if (code in 200..299) {
            connection.inputStream
        } else {
            connection.errorStream
        }

        val body = stream?.bufferedReader()?.use {
            it.readText()
        }.orEmpty()

        if (code !in 200..299) {
            val detail = runCatching {
                JSONObject(body).optString("detail")
            }.getOrNull()

            throw IllegalStateException(
                detail?.takeIf { it.isNotBlank() }
                    ?: "El servidor respondió HTTP $code."
            )
        }

        return body
    }

    suspend fun send(
        backendUrl: String,
        accessToken: String,
        message: String,
        history: List<ChatTurn>
    ): String = withContext(Dispatchers.IO) {

        val connection = createConnection(
            backendUrl,
            "chat",
            accessToken,
            90000
        )

        try {
            val turns = JSONArray()

            history.forEach { turn ->
                turns.put(
                    JSONObject()
                        .put("role", turn.role)
                        .put("content", turn.content)
                )
            }

            turns.put(
                JSONObject()
                    .put("role", "user")
                    .put("content", message)
            )

            val payload = JSONObject()
                .put("messages", turns)
                .toString()

            connection.outputStream.use {
                it.write(payload.toByteArray(Charsets.UTF_8))
            }

            val body = readResponse(connection)
            val reply = JSONObject(body).optString("reply")

            if (reply.isBlank()) {
                throw IllegalStateException(
                    "El servidor devolvió una respuesta vacía."
                )
            }

            reply

        } finally {
            connection.disconnect()
        }
    }

    suspend fun generateImage(
        backendUrl: String,
        accessToken: String,
        prompt: String,
        imageBase64: String? = null,
        mimeType: String = "image/jpeg"
    ): GeneratedImage = withContext(Dispatchers.IO) {

        val connection = createConnection(
            backendUrl,
            "images",
            accessToken,
            180000
        )

        try {
            val payload = JSONObject()
                .put("prompt", prompt)

            if (!imageBase64.isNullOrBlank()) {
                payload.put("image_base64", imageBase64)
                payload.put("mime_type", mimeType)
            }

            connection.outputStream.use {
                it.write(payload.toString().toByteArray(Charsets.UTF_8))
            }

            val body = JSONObject(readResponse(connection))

            val image = body.optString("image_base64")
            val mime = body.optString("mime_type", "image/png")

            if (image.isBlank()) {
                throw IllegalStateException(
                    "El servidor no devolvió ninguna imagen."
                )
            }

            GeneratedImage(
                base64 = image,
                mimeType = mime
            )

        } finally {
            connection.disconnect()
        }
    }
}
