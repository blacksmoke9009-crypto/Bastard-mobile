
package com.bastard.ai

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

private val Bg = Color(0xFF0D0B14)
private val Panel = Color(0xFF171321)
private val Panel2 = Color(0xFF211A30)
private val Purple = Color(0xFF9B70FF)
private val Muted = Color(0xFFAAA2BA)
private val White = Color(0xFFF7F4FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            BastardTheme {
                BastardApp()
            }
        }
    }
}

@Composable
fun BastardTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Purple,
            background = Bg,
            surface = Panel,
            onPrimary = White,
            onBackground = White,
            onSurface = White
        ),
        content = content
    )
}

enum class Destination {
    CHAT,
    CODING,
    IMAGES,
    VIDEOS,
    SETTINGS
}

data class ChatMessage(
    val role: String,
    val content: String
)

@Composable
fun BastardApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val preferences = remember {
        context.getSharedPreferences(
            "bastard_settings",
            Context.MODE_PRIVATE
        )
    }

    var backendUrl by remember {
        mutableStateOf(
            preferences.getString(
                "backend_url",
                "https://bastard-backend.onrender.com"
            ) ?: ""
        )
    }

    var accessToken by remember {
        mutableStateOf(
            preferences.getString("access_token", "") ?: ""
        )
    }

    var destination by remember {
        mutableStateOf(Destination.CHAT)
    }

    var draft by remember {
        mutableStateOf("")
    }

    var messages by remember {
        mutableStateOf(
            listOf(
                ChatMessage(
                    "assistant",
                    "Hola. Soy BASTARD. ¿Qué vamos a hacer hoy?"
                )
            )
        )
    }

    var sending by remember {
        mutableStateOf(false)
    }

    var status by remember {
        mutableStateOf("")
    }

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(
                containerColor = Panel,
                contentColor = White
            ) {

                NavigationBarItem(
                    selected = destination == Destination.CHAT,
                    onClick = { destination = Destination.CHAT },
                    icon = {
                        Icon(
                            Icons.Default.Chat,
                            contentDescription = "Chat"
                        )
                    },
                    label = { Text("Chat") },
                    colors = navigationColors()
                )

                NavigationBarItem(
                    selected = destination == Destination.CODING,
                    onClick = { destination = Destination.CODING },
                    icon = {
                        Icon(
                            Icons.Default.Code,
                            contentDescription = "Coding"
                        )
                    },
                    label = { Text("Coding") },
                    colors = navigationColors()
                )

                NavigationBarItem(
                    selected = destination == Destination.IMAGES,
                    onClick = { destination = Destination.IMAGES },
                    icon = {
                        Icon(
                            Icons.Default.AddPhotoAlternate,
                            contentDescription = "Images"
                        )
                    },
                    label = { Text("Images") },
                    colors = navigationColors()
                )

                NavigationBarItem(
                    selected = destination == Destination.VIDEOS,
                    onClick = { destination = Destination.VIDEOS },
                    icon = {
                        Icon(
                            Icons.Default.Movie,
                            contentDescription = "Videos"
                        )
                    },
                    label = { Text("Videos") },
                    colors = navigationColors()
                )

                NavigationBarItem(
                    selected = destination == Destination.SETTINGS,
                    onClick = { destination = Destination.SETTINGS },
                    icon = {
                        Icon(
                            Icons.Default.Settings,
                            contentDescription = "Settings"
                        )
                    },
                    label = { Text("Settings") },
                    colors = navigationColors()
                )
            }
        }
    ) { padding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Bg)
        ) {

            TopBar()

            when (destination) {

                Destination.CHAT -> {
                    ChatScreen(
                        messages = messages,
                        draft = draft,
                        onDraftChange = { draft = it },
                        sending = sending,
                        status = status,
                        onSend = {
                            val text = draft.trim()

                            if (text.isNotBlank() && !sending) {
                                draft = ""
                                sending = true
                                status = ""

                                scope.launch {
                                    try {
                                        val history = messages.map {
                                            ChatTurn(it.role, it.content)
                                        }

                                        messages = messages + ChatMessage(
                                            "user",
                                            text
                                        )

                                        val reply = BackendClient.send(
                                            backendUrl,
                                            accessToken,
                                            text,
                                            history
                                        )

                                        messages = messages + ChatMessage(
                                            "assistant",
                                            reply
                                        )

                                    } catch (e: Exception) {
                                        status = e.message
                                            ?: "Ocurrió un error."
                                    } finally {
                                        sending = false
                                    }
                                }
                            }
                        }
                    )
                }

                Destination.CODING -> {
                    ModuleScreen(
                        title = "Coding Agent",
                        description = "Tu espacio para programar con BASTARD."
                    )
                }

                Destination.IMAGES -> {
                    ImageStudioScreen(
                        backendUrl = backendUrl,
                        accessToken = accessToken
                    )
                }

                Destination.VIDEOS -> {
                    ModuleScreen(
                        title = "Video Studio",
                        description = "Generación y edición de videos."
                    )
                }

                Destination.SETTINGS -> {
                    SettingsScreen(
                        backendUrl = backendUrl,
                        accessToken = accessToken,
                        onSave = { url, token ->
                            backendUrl = url
                            accessToken = token

                            preferences.edit()
                                .putString("backend_url", url)
                                .putString("access_token", token)
                                .apply()

                            status = "Configuración guardada."
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun navigationColors() =
    NavigationBarItemDefaults.colors(
        selectedIconColor = Purple,
        selectedTextColor = Purple,
        indicatorColor = Panel2,
        unselectedIconColor = Muted,
        unselectedTextColor = Muted
    )

@Composable
fun TopBar() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Panel)
            .padding(horizontal = 18.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Purple),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Default.Bolt,
                contentDescription = null,
                tint = White
            )
        }

        Spacer(Modifier.width(12.dp))

        Column {
            Text(
                "BASTARD",
                color = White,
                fontSize = 19.sp,
                fontWeight = FontWeight.Bold
            )

            Text(
                "Personal AI",
                color = Muted,
                fontSize = 11.sp
            )
        }

        Spacer(Modifier.weight(1f))

        Box(
            modifier = Modifier
                .size(9.dp)
                .clip(CircleShape)
                .background(Color(0xFF4ADE80))
        )
    }
}

@Composable
fun ChatScreen(
    messages: List<ChatMessage>,
    draft: String,
    onDraftChange: (String) -> Unit,
    sending: Boolean,
    status: String,
    onSend: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp)
    ) {

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(messages) { message ->

                val isUser = message.role == "user"

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isUser) {
                        Arrangement.End
                    } else {
                        Arrangement.Start
                    }
                ) {
                    Box(
                        modifier = Modifier
                            .widthIn(max = 310.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(
                                if (isUser) Panel2 else Panel
                            )
                            .padding(14.dp)
                    ) {
                        Text(
                            message.content,
                            color = White,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }

        if (status.isNotBlank()) {
            Text(
                status,
                color = Color(0xFFFF8585),
                fontSize = 12.sp,
                modifier = Modifier.padding(vertical = 6.dp)
            )
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Panel)
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {

            BasicTextField(
                value = draft,
                onValueChange = onDraftChange,
                modifier = Modifier
                    .weight(1f)
                    .padding(10.dp),
                textStyle = androidx.compose.ui.text.TextStyle(
                    color = White,
                    fontSize = 14.sp
                ),
                decorationBox = { inner ->
                    Box {
                        if (draft.isEmpty()) {
                            Text(
                                "Escribí un mensaje...",
                                color = Muted,
                                fontSize = 14.sp
                            )
                        }
                        inner()
                    }
                }
            )

            IconButton(
                onClick = onSend,
                enabled = !sending
            ) {
                if (sending) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        color = Purple,
                        strokeWidth = 2.dp
                    )
                } else {
                    Icon(
                        Icons.Default.Send,
                        contentDescription = "Enviar",
                        tint = Purple
                    )
                }
            }
        }
    }
}

@Composable
fun ImageStudioScreen(
    backendUrl: String,
    accessToken: String
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var prompt by remember {
        mutableStateOf("")
    }

    var sourceBase64 by remember {
        mutableStateOf<String?>(null)
    }

    var sourceMime by remember {
        mutableStateOf("image/jpeg")
    }

    var sourceBitmap by remember {
        mutableStateOf<Bitmap?>(null)
    }

    var resultBase64 by remember {
        mutableStateOf<String?>(null)
    }

    var resultMime by remember {
        mutableStateOf("image/png")
    }

    var loading by remember {
        mutableStateOf(false)
    }

    var status by remember {
        mutableStateOf("")
    }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->

        if (uri != null) {
            scope.launch {
                try {
                    val prepared = prepareImage(context, uri)

                    sourceBase64 = prepared.first
                    sourceBitmap = prepared.second
                    sourceMime = "image/jpeg"

                    status = "Imagen cargada."

                } catch (e: Exception) {
                    status = e.message
                        ?: "No se pudo cargar la imagen."
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {

        Text(
            "Image Studio",
            color = White,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )

        Text(
            "Generá imágenes o transformá tus propias fotos.",
            color = Muted,
            fontSize = 13.sp
        )

        Spacer(Modifier.height(16.dp))

        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {

            OutlinedButton(
                onClick = {
                    imagePicker.launch("image/*")
                }
            ) {
                Icon(
                    Icons.Default.AddPhotoAlternate,
                    contentDescription = null
                )

                Spacer(Modifier.width(6.dp))

                Text("Agregar imagen")
            }

            if (sourceBase64 != null) {
                OutlinedButton(
                    onClick = {
                        sourceBase64 = null
                        sourceBitmap = null
                        status = ""
                    }
                ) {
                    Text("Quitar")
                }
            }
        }

        sourceBitmap?.let { bitmap ->

            Spacer(Modifier.height(12.dp))

            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = "Imagen de referencia",
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 180.dp)
                    .clip(RoundedCornerShape(16.dp)),
                contentScale = ContentScale.Fit
            )
        }

        Spacer(Modifier.height(14.dp))

        Text(
            "¿Qué imagen querés crear?",
            color = White,
            fontWeight = FontWeight.SemiBold
        )

        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = prompt,
            onValueChange = { prompt = it },
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 110.dp),
            placeholder = {
                Text(
                    "Describí la imagen o los cambios que querés..."
                )
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Purple,
                unfocusedBorderColor = Panel2,
                focusedTextColor = White,
                unfocusedTextColor = White,
                focusedPlaceholderColor = Muted,
                unfocusedPlaceholderColor = Muted
            ),
            shape = RoundedCornerShape(16.dp)
        )

        Spacer(Modifier.height(12.dp))

        Button(
            onClick = {
                if (prompt.isNotBlank() && !loading) {
                    loading = true
                    status = ""
                    resultBase64 = null

                    scope.launch {
                        try {
                            val generated = BackendClient.generateImage(
                                backendUrl = backendUrl,
                                accessToken = accessToken,
                                prompt = prompt,
                                imageBase64 = sourceBase64,
                                mimeType = sourceMime
                            )

                            resultBase64 = generated.base64
                            resultMime = generated.mimeType

                            status = "Imagen generada correctamente."

                        } catch (e: Exception) {
                            status = e.message
                                ?: "No se pudo generar la imagen."
                        } finally {
                            loading = false
                        }
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = prompt.isNotBlank() && !loading,
            colors = ButtonDefaults.buttonColors(
                containerColor = Purple,
                contentColor = White
            ),
            shape = RoundedCornerShape(14.dp)
        ) {

            if (loading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(20.dp),
                    color = White,
                    strokeWidth = 2.dp
                )

                Spacer(Modifier.width(8.dp))

                Text("Generando...")

            } else {
                Icon(
                    Icons.Default.AutoAwesome,
                    contentDescription = null
                )

                Spacer(Modifier.width(8.dp))

                Text("Generar imagen")
            }
        }

        if (status.isNotBlank()) {
            Spacer(Modifier.height(10.dp))

            Text(
                status,
                color = if (
                    status.contains("correctamente") ||
                    status.contains("cargada") ||
                    status.contains("guardada")
                ) {
                    Color(0xFF4ADE80)
                } else {
                    Color(0xFFFF8585)
                },
                fontSize = 12.sp
            )
        }

        resultBase64?.let { encoded ->

            val bitmap = remember(encoded) {
                try {
                    val bytes = Base64.decode(
                        encoded,
                        Base64.DEFAULT
                    )

                    BitmapFactory.decodeByteArray(
                        bytes,
                        0,
                        bytes.size
                    )
                } catch (_: Exception) {
                    null
                }
            }

            if (bitmap != null) {

                Spacer(Modifier.height(16.dp))

                Text(
                    "Resultado",
                    color = White,
                    fontWeight = FontWeight.Bold
                )

                Spacer(Modifier.height(8.dp))

                Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = "Imagen generada",
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 300.dp)
                        .clip(RoundedCornerShape(16.dp)),
                    contentScale = ContentScale.Fit
                )

                Spacer(Modifier.height(10.dp))

                Button(
                    onClick = {
                        scope.launch {
                            try {
                                saveImageToGallery(
                                    context,
                                    encoded,
                                    resultMime
                                )

                                status =
                                    "Imagen guardada en Pictures/BASTARD."

                            } catch (e: Exception) {
                                status = e.message
                                    ?: "No se pudo guardar la imagen."
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Panel2
                    )
                ) {
                    Icon(
                        Icons.Default.Download,
                        contentDescription = null
                    )

                    Spacer(Modifier.width(8.dp))

                    Text("Guardar en galería")
                }
            }
        }
    }
}

private suspend fun prepareImage(
    context: Context,
    uri: android.net.Uri
): Pair<String, Bitmap> = withContext(Dispatchers.IO) {

    val original = context.contentResolver
        .openInputStream(uri)
        ?.use {
            BitmapFactory.decodeStream(it)
        } ?: throw IllegalStateException(
        "No se pudo leer la imagen."
    )

    val maxSize = 1600

    val scale = minOf(
        1f,
        maxSize.toFloat() / maxOf(
            original.width,
            original.height
        )
    )

    val resized = if (scale < 1f) {
        Bitmap.createScaledBitmap(
            original,
            (original.width * scale).toInt(),
            (original.height * scale).toInt(),
            true
        )
    } else {
        original
    }

    val output = ByteArrayOutputStream()

    resized.compress(
        Bitmap.CompressFormat.JPEG,
        88,
        output
    )

    val encoded = Base64.encodeToString(
        output.toByteArray(),
        Base64.NO_WRAP
    )

    Pair(encoded, resized)
}

private suspend fun saveImageToGallery(
    context: Context,
    base64: String,
    mimeType: String
) = withContext(Dispatchers.IO) {

    val bytes = Base64.decode(
        base64,
        Base64.DEFAULT
    )

    val extension = if (mimeType.contains("png")) {
        "png"
    } else {
        "jpg"
    }

    val fileName =
        "BASTARD_${System.currentTimeMillis()}.$extension"

    val values = ContentValues().apply {
        put(
            MediaStore.Images.Media.DISPLAY_NAME,
            fileName
        )

        put(
            MediaStore.Images.Media.MIME_TYPE,
            mimeType
        )

        put(
            MediaStore.Images.Media.RELATIVE_PATH,
            "Pictures/BASTARD"
        )
    }

    val resolver = context.contentResolver

    val uri = resolver.insert(
        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
        values
    ) ?: throw IllegalStateException(
        "No se pudo crear el archivo en la galería."
    )

    try {
        resolver.openOutputStream(uri)?.use {
            it.write(bytes)
        } ?: throw IllegalStateException(
            "No se pudo guardar la imagen."
        )

    } catch (e: Exception) {
        resolver.delete(uri, null, null)
        throw e
    }
}

@Composable
fun SettingsScreen(
    backendUrl: String,
    accessToken: String,
    onSave: (String, String) -> Unit
) {
    var url by remember(backendUrl) {
        mutableStateOf(backendUrl)
    }

    var token by remember(accessToken) {
        mutableStateOf(accessToken)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {

        Text(
            "Settings",
            color = White,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )

        OutlinedTextField(
            value = url,
            onValueChange = { url = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Backend URL") },
            singleLine = true
        )

        OutlinedTextField(
            value = token,
            onValueChange = { token = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Access token") },
            singleLine = true
        )

        Button(
            onClick = {
                onSave(url.trim(), token.trim())
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(
                containerColor = Purple
            )
        ) {
            Text("Guardar configuración")
        }
    }
}

@Composable
fun ModuleScreen(
    title: String,
    description: String
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Icon(
            Icons.Default.Construction,
            contentDescription = null,
            tint = Purple,
            modifier = Modifier.size(48.dp)
        )

        Spacer(Modifier.height(16.dp))

        Text(
            title,
            color = White,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(Modifier.height(8.dp))

        Text(
            description,
            color = Muted
        )
    }
}
