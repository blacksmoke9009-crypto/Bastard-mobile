package com.bastard.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF101015)
private val Panel = Color(0xFF19171F)
private val Panel2 = Color(0xFF24202D)
private val Purple = Color(0xFFAA8AF4)
private val Muted = Color(0xFF918D9D)
private val White = Color(0xFFECEAF2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BastardTheme { BastardApp() } }
    }
}

@Composable
private fun BastardTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg, surface = Panel, primary = Purple,
            onBackground = White, onSurface = White, secondary = Muted
        ),
        content = content
    )
}

private enum class Destination(val label: String) {
    CHAT("Chat"), CODING("Coding Agent"), IMAGES("Image Studio"),
    VIDEOS("Video Studio"), SETTINGS("Ajustes")
}
private data class ChatMessage(val fromUser: Boolean, val text: String)

@Composable
private fun BastardApp() {
    var selected by remember { mutableStateOf(Destination.CHAT) }
    var draft by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf<ChatMessage>()) }

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF15141B), contentColor = White) {
                val items = listOf(Destination.CHAT, Destination.CODING, Destination.IMAGES, Destination.VIDEOS, Destination.SETTINGS)
                items.forEach { dest ->
                    val icon = when (dest) {
                        Destination.CHAT -> Icons.Default.ChatBubbleOutline
                        Destination.CODING -> Icons.Default.Code
                        Destination.IMAGES -> Icons.Default.Image
                        Destination.VIDEOS -> Icons.Default.Movie
                        Destination.SETTINGS -> Icons.Default.Settings
                    }
                    NavigationBarItem(
                        selected = selected == dest,
                        onClick = { selected = dest },
                        icon = { Icon(icon, contentDescription = dest.label) },
                        label = { Text(dest.label, fontSize = 9.sp, maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Purple, selectedTextColor = Purple,
                            indicatorColor = Panel2, unselectedIconColor = Muted,
                            unselectedTextColor = Muted
                        )
                    )
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).background(Bg)) {
            TopBar(selected)
            when (selected) {
                Destination.CHAT -> ChatScreen(
                    messages = messages, draft = draft, onDraft = { draft = it },
                    onSend = {
                        val text = draft.trim()
                        if (text.isNotEmpty()) {
                            messages = messages + ChatMessage(true, text) +
                                ChatMessage(false, "Recibí tu mensaje. BASTARD está en modo demostración: todavía falta conectar el proveedor de IA remoto.")
                            draft = ""
                        }
                    },
                    onClear = { messages = emptyList() }
                )
                Destination.CODING -> ModuleScreen(
                    icon = Icons.Default.Code, title = "Coding Agent",
                    subtitle = "Tu compañero para desarrollar proyectos.",
                    details = listOf("Analizar carpetas y archivos", "Proponer cambios y mostrar diferencias", "Ejecutar pruebas con permisos", "Conectarse con VS Code")
                )
                Destination.IMAGES -> ModuleScreen(
                    icon = Icons.Default.Image, title = "Image Studio",
                    subtitle = "Generación y edición de imágenes.",
                    details = listOf("Texto a imagen", "Imagen a imagen", "Galería de resultados", "Modelos remotos intercambiables")
                )
                Destination.VIDEOS -> ModuleScreen(
                    icon = Icons.Default.Movie, title = "Video Studio",
                    subtitle = "Creación de videos con IA.",
                    details = listOf("Texto a video", "Imagen a video", "Cola y progreso de trabajos", "Vista previa y exportación")
                )
                Destination.SETTINGS -> ModuleScreen(
                    icon = Icons.Default.Tune, title = "Ajustes",
                    subtitle = "Configurá cómo funciona BASTARD.",
                    details = listOf("Modo híbrido", "Proveedores de IA", "Autonomía del agente", "Privacidad y almacenamiento")
                )
            }
        }
    }
}

@Composable
private fun TopBar(destination: Destination) {
    Row(
        Modifier.fillMaxWidth().background(Color(0xFF141319)).padding(horizontal = 18.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(36.dp).background(BrushPurple, RoundedCornerShape(11.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("BASTARD", fontWeight = FontWeight.Black, letterSpacing = 2.sp, fontSize = 16.sp)
            Text("PERSONAL AI WORKSPACE", color = Muted, fontSize = 8.sp, letterSpacing = 1.2.sp)
        }
        Surface(color = Color(0xFF1C2B25), shape = CircleShape) {
            Row(Modifier.padding(horizontal = 9.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(6.dp).background(Color(0xFF65C995), CircleShape))
                Spacer(Modifier.width(6.dp))
                Text("HYBRID", color = Color(0xFF8BD5AE), fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
    if (destination != Destination.CHAT) {
        Text(destination.label.uppercase(), Modifier.padding(start = 20.dp, top = 14.dp), color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
    }
}
private val BrushPurple = Color(0xFF7650C8)

@Composable
private fun ChatScreen(
    messages: List<ChatMessage>, draft: String, onDraft: (String) -> Unit,
    onSend: () -> Unit, onClear: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        if (messages.isEmpty()) {
            Column(Modifier.weight(1f).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Box(Modifier.size(66.dp).background(Panel2, RoundedCornerShape(20.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Purple, modifier = Modifier.size(30.dp))
                }
                Spacer(Modifier.height(20.dp))
                Text("¿Qué vamos a", color = White, fontSize = 27.sp, fontWeight = FontWeight.SemiBold)
                Text("crear hoy?", color = Purple, fontSize = 29.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(9.dp))
                Text("Pensá, programá y creá desde un mismo lugar.", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(27.dp))
                QuickCard(Icons.Default.Code, "Construir un proyecto", "Arquitectura, código y debugging") { onDraft("Ayudame a desarrollar un proyecto desde cero.") }
                Spacer(Modifier.height(9.dp))
                QuickCard(Icons.Default.Image, "Generar una imagen", "Ideas visuales y edición") { onDraft("Quiero generar una imagen: ") }
                Spacer(Modifier.height(9.dp))
                QuickCard(Icons.Default.Movie, "Crear un video", "Texto e imagen a video") { onDraft("Quiero crear un video: ") }
            }
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onClear) { Text("Nueva conversación", color = Muted, fontSize = 11.sp) }
            }
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(messages) { message ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start) {
                        Surface(color = if (message.fromUser) Color(0xFF302742) else Panel, shape = RoundedCornerShape(14.dp)) {
                            Text(message.text, Modifier.widthIn(max = 290.dp).padding(13.dp), color = White, fontSize = 13.sp, lineHeight = 19.sp)
                        }
                    }
                }
            }
        }
        Surface(color = Panel, shape = RoundedCornerShape(16.dp), tonalElevation = 2.dp, modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
            Column(Modifier.padding(10.dp)) {
                OutlinedTextField(
                    value = draft, onValueChange = onDraft, modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Escribí tu mensaje…", color = Muted, fontSize = 13.sp) },
                    minLines = 2, maxLines = 5,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color.Transparent, unfocusedBorderColor = Color.Transparent,
                        focusedTextColor = White, unfocusedTextColor = White, cursorColor = Purple
                    )
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onSend, enabled = draft.isNotBlank()) {
                        Icon(Icons.Default.ArrowUpward, contentDescription = "Enviar", tint = if (draft.isNotBlank()) Purple else Muted)
                    }
                }
            }
        }
        Text("La IA puede cometer errores. Revisá sus respuestas y cambios.", Modifier.align(Alignment.CenterHorizontally).padding(bottom = 5.dp), color = Color(0xFF666371), fontSize = 9.sp)
    }
}

@Composable
private fun QuickCard(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Surface(color = Panel, shape = RoundedCornerShape(12.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF302D38)), modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = Purple, modifier = Modifier.size(21.dp))
            Spacer(Modifier.width(12.dp))
            Column {
                Text(title, color = White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Text(subtitle, color = Muted, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun ModuleScreen(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String, subtitle: String, details: List<String>
) {
    Column(Modifier.fillMaxSize().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(62.dp).background(Panel2, RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = null, tint = Purple, modifier = Modifier.size(29.dp))
        }
        Spacer(Modifier.height(18.dp))
        Text(title, color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(7.dp))
        Text(subtitle, color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(25.dp))
        Surface(color = Panel, shape = RoundedCornerShape(14.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF302D38))) {
            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                Text("MÓDULO PLANIFICADO", color = Purple, fontSize = 9.sp, letterSpacing = 1.3.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                details.forEach { detail ->
                    Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircleOutline, contentDescription = null, tint = Color(0xFF7CC9A1), modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(10.dp))
                        Text(detail, color = White, fontSize = 12.sp)
                    }
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("La interfaz está lista como base. Falta conectar el servicio remoto.", color = Muted, fontSize = 10.sp)
    }
}
