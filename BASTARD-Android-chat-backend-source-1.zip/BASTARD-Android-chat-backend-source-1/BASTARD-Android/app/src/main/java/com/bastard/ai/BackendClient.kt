package com.bastard.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class ChatTurn(val role: String, val content: String)

object BackendClient {
    suspend fun send(
        backendUrl: String,
        accessToken: String,
        message: String,
        history: List<ChatTurn>
    ): String = withContext(Dispatchers.IO) {
        val root = backendUrl.trim().trimEnd('/')
        require(root.startsWith("https://") || root.startsWith("http://10.0.2.2")) {
            "Usá una dirección HTTPS para el servidor (o 10.0.2.2 para pruebas locales)."
        }

        val connection = (URL("$root/chat").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 90000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            if (accessToken.isNotBlank()) setRequestProperty("Authorization", "Bearer $accessToken")
        }

        try {
            val turns = JSONArray()
            history.forEach { turn ->
                turns.put(JSONObject().put("role", turn.role).put("content", turn.content))
            }
            turns.put(JSONObject().put("role", "user").put("content", message))
            val payload = JSONObject().put("messages", turns).toString()
            connection.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }

            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val detail = runCatching { JSONObject(body).optString("detail") }.getOrNull()
                throw IllegalStateException(detail?.takeIf { it.isNotBlank() } ?: "El servidor respondió HTTP $code.")
            }
            val reply = JSONObject(body).optString("reply")
            if (reply.isBlank()) throw IllegalStateException("El servidor devolvió una respuesta vacía.")
            reply
        } finally {
            connection.disconnect()
        }
    }
}
