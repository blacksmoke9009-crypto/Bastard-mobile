
import os
import secrets
import base64
import json
from typing import List, Literal

import httpx
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel


app = FastAPI(title="BASTARD Backend", version="0.3.0")

ACCESS_TOKEN = os.getenv("BASTARD_ACCESS_TOKEN", "")
PROVIDER_API_KEY = os.getenv("PROVIDER_API_KEY", "")
PROVIDER_BASE_URL = os.getenv(
    "PROVIDER_BASE_URL",
    "https://openrouter.ai/api/v1"
).rstrip("/")

PROVIDER_MODEL = os.getenv("PROVIDER_MODEL", "openrouter/free")

CF_ACCOUNT_ID = os.getenv("CF_ACCOUNT_ID", "")
CF_API_TOKEN = os.getenv("CF_API_TOKEN", "")

CF_IMAGE_MODEL = "@cf/black-forest-labs/flux-1-schnell"


class Message(BaseModel):
    role: Literal["user", "assistant"]
    content: str


class ChatRequest(BaseModel):
    messages: List[Message]


class ImageRequest(BaseModel):
    prompt: str
    image_base64: str | None = None
    mime_type: str = "image/jpeg"


def check_access(authorization: str | None):
    if ACCESS_TOKEN:
        supplied = (authorization or "").removeprefix("Bearer ").strip()
        if not secrets.compare_digest(supplied, ACCESS_TOKEN):
            raise HTTPException(
                status_code=401,
                detail="Token de acceso incorrecto."
            )


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "service": "bastard-backend"
    }


@app.post("/chat")
async def chat(
    request: ChatRequest,
    authorization: str | None = Header(default=None)
):
    check_access(authorization)

    if not PROVIDER_API_KEY:
        raise HTTPException(
            status_code=503,
            detail="Falta configurar PROVIDER_API_KEY."
        )

    if not request.messages:
        raise HTTPException(
            status_code=400,
            detail="No hay mensajes para enviar."
        )

    payload = {
        "model": PROVIDER_MODEL,
        "messages": [m.model_dump() for m in request.messages],
        "stream": False,
    }

    headers = {
        "Authorization": f"Bearer {PROVIDER_API_KEY}",
        "Content-Type": "application/json"
    }

    try:
        async with httpx.AsyncClient(timeout=90) as client:
            response = await client.post(
                f"{PROVIDER_BASE_URL}/chat/completions",
                json=payload,
                headers=headers
            )

        if response.status_code >= 400:
            raise HTTPException(
                status_code=502,
                detail=f"El proveedor de chat respondió HTTP {response.status_code}."
            )

        data = response.json()
        reply = data["choices"][0]["message"]["content"]

        if isinstance(reply, list):
            reply = "".join(
                part.get("text", "")
                for part in reply
                if isinstance(part, dict)
            )

        return {"reply": str(reply)}

    except HTTPException:
        raise
    except (httpx.HTTPError, KeyError, IndexError, ValueError):
        raise HTTPException(
            status_code=502,
            detail="No se pudo completar la solicitud al proveedor de IA."
        )


@app.post("/images")
async def generate_image(
    request: ImageRequest,
    authorization: str | None = Header(default=None)
):
    check_access(authorization)

    if not CF_ACCOUNT_ID or not CF_API_TOKEN:
        raise HTTPException(
            status_code=503,
            detail="Falta configurar Cloudflare en Render."
        )

    if not request.prompt.strip():
        raise HTTPException(
            status_code=400,
            detail="Escribí una descripción para generar la imagen."
        )

    if request.image_base64:
        raise HTTPException(
            status_code=400,
            detail="Por ahora Image Studio solamente admite generación desde texto."
        )

    url = (
        "https://api.cloudflare.com/client/v4/accounts/"
        f"{CF_ACCOUNT_ID}/ai/run/{CF_IMAGE_MODEL}"
    )

    headers = {
        "Authorization": f"Bearer {CF_API_TOKEN}",
        "Content-Type": "application/json"
    }

    payload = {
        "prompt": request.prompt.strip()
    }

    try:
        async with httpx.AsyncClient(timeout=180) as client:
            response = await client.post(
                url,
                json=payload,
                headers=headers
            )

        if response.status_code >= 400:
            error_message = "Error desconocido"

            try:
                error_data = response.json()
                errors = error_data.get("errors", [])
                if errors:
                    error_message = errors[0].get(
                        "message", error_message
                    )
            except (ValueError, AttributeError):
                pass

            raise HTTPException(
                status_code=502,
                detail=(
                    f"Cloudflare respondió HTTP "
                    f"{response.status_code}: {error_message}"
                )
            )

        content_type = response.headers.get(
            "content-type", ""
        ).lower()

        if "application/json" in content_type:
            data = response.json()
            result = data.get("result")

            if not result:
                raise HTTPException(
                    status_code=502,
                    detail="Cloudflare no devolvió ninguna imagen."
                )

            if isinstance(result, str):
                image_data = result
            elif isinstance(result, dict):
                image_data = result.get("image", "")
            else:
                image_data = ""

            if not image_data:
                raise HTTPException(
                    status_code=502,
                    detail="Formato de imagen no reconocido."
                )

            if image_data.startswith("data:"):
                image_data = image_data.split(",", 1)[1]

            try:
                image_bytes = base64.b64decode(image_data)
            except ValueError:
                image_bytes = image_data.encode("utf-8")

        else:
            image_bytes = response.content

        if not image_bytes:
            raise HTTPException(
                status_code=502,
                detail="La imagen recibida está vacía."
            )

        image_base64 = base64.b64encode(
            image_bytes
        ).decode("utf-8")

        return {
            "image_base64": image_base64,
            "mime_type": "image/png",
            "cost": None
        }

    except HTTPException:
        raise
    except httpx.HTTPError:
        raise HTTPException(
            status_code=502,
            detail="No se pudo conectar con Cloudflare."
        )
